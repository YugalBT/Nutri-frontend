export interface TechnicalReport {
    
}
