export interface Companysetting {
}
